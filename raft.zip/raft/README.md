# Raft

<!-- **TODO: Add description** -->
## Run
Before running the algorithm, parameters can be changed in the Makefile and configuration.ex to explore the performance of our Raft implementation under different scenarios.
```
make
```

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed
by adding `raft` to your list of dependencies in `mix.exs`:

```elixir
def deps do
  [
    {:raft, "~> 0.1.0"}
  ]
end
```

Documentation can be generated with [ExDoc](https://github.com/elixir-lang/ex_doc)
and published on [HexDocs](https://hexdocs.pm). Once published, the docs can
be found at <https://hexdocs.pm/raft>.

